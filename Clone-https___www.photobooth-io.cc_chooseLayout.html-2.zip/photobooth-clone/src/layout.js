// Get DOM elements for layout buttons
const layout1Btn = document.getElementById('layout1Btn');
const layout2Btn = document.getElementById('layout2Btn');
const layout3Btn = document.getElementById('layout3Btn');
const layout4Btn = document.getElementById('layout4Btn');

// Function to handle layout selection
function selectLayout(layoutId) {
  // Store selected layout in localStorage for later use
  localStorage.setItem('selectedLayout', layoutId);

  // In a real app, this would navigate to the next page
  // For now, we'll just add a basic animation and log the selection
  console.log(`Selected layout: ${layoutId}`);

  // In a full implementation, this would redirect to the photobooth page
  // window.location.href = 'booth.html';

  // For demo purposes, show a selection indicator
  const buttons = [layout1Btn, layout2Btn, layout3Btn, layout4Btn];

  buttons.forEach((btn) => {
    if (btn) {
      btn.style.borderColor = '#1a4b8c'; // Dark blue
      btn.style.boxShadow = 'none';
    }
  });

  // Highlight the selected button
  const selectedButton = document.getElementById(`${layoutId}Btn`);
  if (selectedButton) {
    selectedButton.style.borderColor = '#3a7bd5'; // Light blue
    selectedButton.style.boxShadow = '0 0 12px rgba(42, 117, 209, 0.4)'; // Blue glow
  }
}

// Add click event listeners to layout buttons
if (layout1Btn) {
  layout1Btn.addEventListener('click', () => selectLayout('layout1'));
}

if (layout2Btn) {
  layout2Btn.addEventListener('click', () => selectLayout('layout2'));
}

if (layout3Btn) {
  layout3Btn.addEventListener('click', () => selectLayout('layout3'));
}

if (layout4Btn) {
  layout4Btn.addEventListener('click', () => selectLayout('layout4'));
}

// Add hover effects to all layout buttons
const allLayoutButtons = [layout1Btn, layout2Btn, layout3Btn, layout4Btn];

allLayoutButtons.forEach((btn) => {
  if (btn) {
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'scale(1.02)';
      btn.style.transition = 'transform 0.2s ease';
    });

    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'scale(1)';
    });
  }
});
