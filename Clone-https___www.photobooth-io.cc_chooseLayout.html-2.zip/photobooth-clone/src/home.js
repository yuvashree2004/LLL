// Get DOM elements
const hamburgerTrigger = document.getElementById('hamburger-home-trigger');
const hamburgerNav = document.getElementById('hamburger-nav');
const hamburgerBtn = document.getElementById('hamburgerBtn');
const homeStartButton = document.getElementById('home-start');
const heroAnimation = document.querySelector('.hero-animation');

// Handle hamburger menu
if (hamburgerTrigger && hamburgerNav && hamburgerBtn) {
  hamburgerTrigger.addEventListener('click', () => {
    hamburgerNav.style.display = 'block';
  });

  hamburgerBtn.addEventListener('click', () => {
    hamburgerNav.style.display = 'none';
  });
}

// Add hover animation to letters
if (heroAnimation) {
  const letters = heroAnimation.querySelectorAll('span');

  letters.forEach((letter, index) => {
    letter.addEventListener('mouseenter', () => {
      letter.style.color = '#3a7bd5'; // Light blue
      letter.style.transform = 'translateY(-5px)';
      letter.style.transition = 'all 0.3s ease';
    });

    letter.addEventListener('mouseleave', () => {
      letter.style.color = '#1a4b8c'; // Dark blue
      letter.style.transform = 'translateY(0)';
    });
  });
}

// Add click animation to the start button
if (homeStartButton) {
  homeStartButton.addEventListener('mousedown', () => {
    homeStartButton.style.transform = 'scale(0.95)';
  });

  homeStartButton.addEventListener('mouseup', () => {
    homeStartButton.style.transform = 'scale(1)';
  });

  homeStartButton.addEventListener('mouseleave', () => {
    homeStartButton.style.transform = 'scale(1)';
  });
}
