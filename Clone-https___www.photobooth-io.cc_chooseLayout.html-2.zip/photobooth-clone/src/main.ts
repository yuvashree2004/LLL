// This file is only used for the initial project setup
// Our actual functionality is in layout.js and home.js
console.log('Photobooth app initialized');
